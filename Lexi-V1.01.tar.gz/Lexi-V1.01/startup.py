import os
import time

os.system("clear")
print("""\u001b[35m
WELCOME TO ...
███████████████████████ TM
█▄─▄███▄─▄▄─█▄─▀─▄█▄─▄█
██─██▀██─▄█▀██▀─▀███─██
▀▄▄▄▄▄▀▄▄▄▄▄▀▄▄█▄▄▀▄▄▄▀

""")
print("""
Welcome to LEXI, DO you want to startup LEXI? (Y/N).
""")
while True:
    startup = input("\u001b[32mStartup:-$ ")
    if startup == 'y':
        os.system("python3 ai.py")
    elif startup == 'n':
        print("\u001b[33m  Canceled Startup . . .")
        break
    if startup == 'Y':
        os.system("python3 ai.py")
    elif startup == 'N':
        print("\u001b[33m  Canceled Startup . . .")
        break
    else:
        print("\u001b[31mSorry, Couldnt find what you were looking for")
