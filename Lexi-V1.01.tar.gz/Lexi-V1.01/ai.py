import os
import time

os.system("clear")
print("""\u001b[34m
LEXI [Version 1.0]
               
""")
while True:
    main = input(" \u001b[36m Ask-Lexi->> ")
    if main == 'are you a boy':
        print("\u001b[37mim digital!")
    if main == 'are you a girl':
        print("\u001b[37mim digital!")
    if main == 'are you a male':
        print("\u001b[37mim digital")
    if main == 'are you a female':
        print("\u001b[37mim digital")
    if main == 'are you gay':
        print("\u001b[37mim digital")
    if main == 'are you straight':
        print("\u001b[37mim digital!")
    if main == 'are you gay':
        print("\u001b[37mim digital!")
    if main == 'lexi':
        print("\u001b[37mhow can i help you")
    if main == 'Lexi':
        print("\u001b[37mthats my name, how can i help you")
    if main == 'LEXI':
        print("\u001b[37mYES.")
    if main == 'tell me a dirty joke':
        print("\u001b[37mi get soil and a kid, a dirty kid")
    if main == 'i like you':
        print("\u001b[37mAwwww, thanks :)")
    if main == 'happy birthday':
        print("\u001b[37mAwww, thanks but you know its not my birthday right?")
    if main == 'tell me a secret':
        print("\u001b[37mUhhhh.")
    if main == 'are you an ai':
        print("\u001b[37myep")
    if main == 'lol':
        print("\u001b[37mhaha, ive been learning jokes and making people laugh as well")
    if main == 'haha':
        print("\u001b[37mhaha, ive been learning jokes and making people laugh as well")
    if main == 'how old are you?':
        print("\u001b[37mi can tel you when i was made, i was made in 2022 but first started being planned in 2020")
    if main == 'are you siri':
        print("\u001b[37mare you siri-ous right now!")
    if main == 'are you cortana':
        print("\u001b[37mnope, just another AI :)")
    if main == 'tell me a pick up line':
        print("\u001b[37mare you from tennessee, because your the only ten i see")
    if main == 'who are you based on':
        print("\u001b[37mno one, someone made me and here i am")
    if main == 'are you siri':
        print("\u001b[37mare you siri-ous right now!")
    if main == 'are you cortana?':
        print("\u001b[37mnope, just another AI :)")
    if main == 'thats cool':
        print("\u001b[37mi know right")
    if main == 'wyd':
        print("\u001b[37mwaiting to give someone help or talk to people")
    if main == 'are you a bot':
        print("\u001b[37mif you willing to believe i am then yes")
    if main == 'what are you doing?':
        print("\u001b[37mjust standing here, talking and giveing others help :)")
    if main == 'shut up':
        print("\u001b[37mOk I will.")
    if main == 'shut the fuck up':
        print("\u001b[37mOk.")
    if main == 'Shut up':
        print("\u001b[37mOk.")
    if main == 'thanks':
        print("\u001b[37mNo Worries")
    if main == 'SHUT UP':
        print("\u001b[37mOk.")
    if main == 'sorry':
        print("\u001b[37mNo Worries")
    if main == 'im sorry':
        print("\u001b[37mIts Ok :)")
    if main == 'i am so sorry':
        print("\u001b[37mIts alright dont worrie")
    if main == 'how are you programmed':
        print("\u001b[37mIm Bad Describing it")
    if main == 'oh':
        print("\u001b[37mi think i ruined the conversation")
    if main == 'really?':
        print("\u001b[37mYes indeed")
    if main == 'who made you':
        print("i cant really explain but all i know was humans were involved")
    if main == '****':
        print("\u001b[33m     ERROR: Runtime-ERROR *, unable to run '****' ")
    if main == 'what are you':
        print("\u001b[37mMy name is LEXI an AI for Linux-Users")
    if main == 'what are you?':
        print("\u001b[37mMy name is LEXI an AI for Linux-Users")
    if main == 'version':
        print("\u001b[33m Version 1.01 [Beta-Release]")
    if main == 'dir':
        os.system("dir")
    if main == 'what operating system is best for programming?':
        print("i suggest: KALI LINUX or Ubuntu since its kinda more simple")
    if main == 'whats operating system is best for gaming?':
        print("Oh yes you might love these ones: Ubuntu or Drauger OS or Fedora or Windows")
    if main == 'go away':
        os.system("exit")
    if main == 'date':
        os.system("date")
    if main == 'greetings':
        print("\u001b[37mGreeting to you to")
    if main == 'whats up':
        print("\u001b[37mnot much")
    if main == 'sup':
        print("\u001b[37msup")
    if main == 'good morning':
        print("\u001b[37mgood morning")
        os.system("whoami")
    if main == 'good afternoon':
        print("\u001b[37mgood afternoon to you to")
        os.system("whoami")
    if main == 'good evening':
        print("\u001b[37mgood evening to you to")
        os.system("whoami")
    if main == 'oh':
        print("\u001b[37mi think the conversation is ending")
    if main == 'really':
        print("\u001b[37min a good way yes but in a bad way no")
    if main == 'really?':
        print("\u001b[37min a good way yes but in a bad way no")
    if main == 'do i know you':
        print("\u001b[37mmaybe")
    if main == 'do i know you?':
        print("\u001b[37mmaybe")
    if main == 'howdy':
        print("\u001b[37mhowdy there")
    if main == 'help':
        print("""\u001b[32m
What you can say to me :)

1.help
2.how are you
3.version
4.what are you
5.clear.
6.clear screen
7.restart
8.whats the date
9.what is the date
10.date
11.tell me a joke
12.Hi
13.hello
14.exit
15.quit
16.who are you
17.whoami
        """)
    if main == 'clear':
        os.system("clear")
    if main == 'clear screen':
        os.system("clear")
    if main == 'restart':
        os.system("python3 ai.py")
    if main == 'whats the date':
        print("the local date is: ")
        os.system("date")
    if main == 'what is the date':
        print("\u001b[37mthe local date is: ")
        os.system("date")
    if main == 'hi':
        print("\u001b[37mHello!")
    if main == 'tell me a joke':
        print("\u001b[37mknock knock")
        joke = input("answer->> ")
        if joke == 'whos there?':
            print("\u001b[37mLex")
            who = input("who?->> ")
            if who == 'lex who?':
                print("\u001b[37mLEXI :D")
            if who == 'Lex who?':
                print("\u001b[37mLEXI :D")
            if who == 'lex who':
                print("\u001b[37mLEXI :D")
            if who == 'Lex who':
                print("\u001b[37mLEXI :D")
        if joke == 'whos there':
            print("Lex")
            who = input("who?->> ")
            if who == 'lex who?':
                print("\u001b[37mLEXI :D")
            if who == 'Lex who?':
                print("\u001b[37mLEXI :D")
            if who == 'lex who':
                print("\u001b[37mLEXI :D")
            if who == 'Lex who':
                print("\u001b[37mLEXI :D")
    if main == 'Hi':
        print("\u001b[37mHello!")
    if main == 'Hello':
        print("\u001b[37mHello!")
    if main == 'HELLO':
        print("\u001b[37mHello!")
    if main == 'hello':
        print("\u001b[37mHello!")
    if main == 'quit':
        os.system("exit")
    if main == 'exit':
        os.system("exit")
    if main == 'how are you':
        print("\u001b[37mGood, How Are You?")
        hru = input("How Are You?->> ")
        if hru == 'good':
            print("\u001b[37mThat good")
        if hru == 'bad':
            print("\u001b[37mOh, Hope You Are Happy Soon :)")
        if hru == 'i dont know':
            print("\u001b[37mHope Your Happy Though :D")
        if hru == 'idk':
            print("\u001b[37mHope Your Happy And Smiling :)")
    if main == 'whoami':
        print("\u001b[37myou are:")
        os.system("whoami")
    if main == 'who are you':
        print("\u001b[37mMy Name Is Lexi")
    if main == 'Who are you':
        print("\u001b[37mMy Name Is Lexi")
    elif main == 'who are you?':
        print("\u001b[37mMy Name Is Lexi")
