import os
import time

print("""\u001b[33m
ERROR: AI Crashed or Went into Emergency Mode!

<Reset Mode>

""")
while True:
    mode = input("\u001b[37mRST-Mode:-$ ")
    if mode == 'Restart':
        print("Restarting . . .")
        os.system("python3 startup.py")
    if mode == 'restart':
        print("Restarting . . .")
        os.system("python3 startup.py")
    if mode == 'details':
        print("AI Iether Crashed Or Went into recovery mode")
    elif mode == 'exit':
        os.system("exit")
    else:
        print("Unknown Command!")
